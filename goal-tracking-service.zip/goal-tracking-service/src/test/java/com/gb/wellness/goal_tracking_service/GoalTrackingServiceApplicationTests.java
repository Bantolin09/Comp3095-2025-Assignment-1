package com.gb.wellness.goal_tracking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoalTrackingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
