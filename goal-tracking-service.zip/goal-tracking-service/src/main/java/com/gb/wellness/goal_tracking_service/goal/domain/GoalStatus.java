package com.gb.wellness.goal_tracking_service.goal.domain;

public enum GoalStatus {
    IN_PROGRESS,
    COMPLETED
}
